import React, { useRef, Suspense, useState, useMemo } from 'react'
import { Canvas, useFrame } from '@react-three/fiber'
import { OrbitControls, Stars } from '@react-three/drei'
import { FiGithub, FiLinkedin, FiMail } from 'react-icons/fi'
import { motion } from 'framer-motion'
import './index.css'

function Spheres({ count = 8 }) {
  const group = useRef()
  const spheres = useMemo(() => {
    const arr = []
    for (let i = 0; i < count; i++) {
      const r = 0.8 + Math.random() * 1.6
      const x = (Math.random() - 0.5) * 8
      const y = (Math.random() - 0.5) * 6
      const z = (Math.random() - 0.5) * 6
      arr.push({ id: i, r, pos: [x, y, z], speed: 0.01 + Math.random() * 0.02 })
    }
    return arr
  }, [count])

  useFrame((state, delta) => {
    if (!group.current) return
    group.current.rotation.y += delta * 0.15
  })

  return (
    <group ref={group}>
      {spheres.map(s => (
        <mesh key={s.id} position={s.pos}>
          <sphereGeometry args={[s.r, 32, 32]} />
          <meshStandardMaterial metalness={0.6} roughness={0.2} color={['#06b6d4','#7c3aed','#ff7ab6','#f59e0b','#34d399','#60a5fa'][s.id % 6]} />
        </mesh>
      ))}
    </group>
  )
}

function Typing({ texts = [], speed = 80 }) {
  const [index, setIndex] = useState(0)
  const [slice, setSlice] = useState('')
  React.useEffect(() => {
    const txt = texts[index]
    let i = 0
    const t = setInterval(() => {
      i++
      setSlice(txt.slice(0, i))
      if (i >= txt.length) {
        clearInterval(t)
        setTimeout(() => setIndex((idx) => (idx + 1) % texts.length), 900)
      }
    }, speed)
    return () => clearInterval(t)
  }, [index, texts, speed])
  return <span className="typing">{slice}<span className="cursor">|</span></span>
}

function ProjectCard({ project }) {
  return (
    <motion.article whileHover={{ y: -6 }} className="project-card">
      <div className="project-body">
        <h4>{project.name}</h4>
        <p className="muted">{project.description}</p>
        <div className="tags">{project.tech.join(' • ')}</div>
      </div>
      <div className="project-links">
        {project.repo && <a href={project.repo} target="_blank" rel="noreferrer">Repo</a>}
      </div>
    </motion.article>
  )
}

export default function App() {
  const nameLine = 'Akhil Vadlakonda | DevOps Engineer'
  const github = 'https://github.com/akhilgou'
  const linkedin = 'https://www.linkedin.com/in/akhilvadlakonda'
  const email = 'v.akhilgoud@gmail.com'
  const profileImg = '/assets/profile.jpg'

  const projects = [
    {
      name: 'CI/CD Platform',
      description: 'Automated multi-environment pipelines using Jenkins, Terraform and Ansible.',
      repo: '',
      tech: ['Jenkins','Terraform','Ansible']
    },
    {
      name: 'Cloud Migration',
      description: 'Migrated legacy VMware workloads to AWS and containerized applications.',
      repo: '',
      tech: ['AWS','Docker','Kubernetes']
    },
    {
      name: 'Monitoring & Observability',
      description: 'Centralized logging and metrics using ELK, Prometheus and Grafana.',
      repo: '',
      tech: ['ELK','Prometheus','Grafana']
    }
  ]

  return (
    <div className="app-root">
      <header className="site-header">
        <div className="brand">
          <img src={profileImg} alt="Akhil" className="avatar" />
          <div>
            <h1>{nameLine}</h1>
            <p className="muted">DevOps • Cloud • Automation</p>
          </div>
        </div>
        <nav className="nav-links">
          <a href="#projects">Projects</a>
          <a href="#about">About</a>
          <a href="#contact">Contact</a>
        </nav>
      </header>

      <main>
        <section className="hero">
          <div className="hero-left">
            <h2>Hello, I’m <strong>Akhil</strong></h2>
            <h3><Typing texts={["DevOps Engineer","Cloud Automation","Kubernetes & Terraform"]} /></h3>
            <p className="muted">I design and operate scalable, secure cloud infrastructure and build automation that helps teams ship faster.</p>
            <div className="cta">
              <a className="btn" href={github} target="_blank" rel="noreferrer">View GitHub</a>
              <a className="btn ghost" href={`mailto:${email}`}>Email me</a>
            </div>
            <div className="socials">
              <a href={github} target="_blank" rel="noreferrer"><FiGithub /></a>
              <a href={linkedin} target="_blank" rel="noreferrer"><FiLinkedin /></a>
              <a href={`mailto:${email}`}><FiMail /></a>
            </div>
          </div>

          <div className="hero-right">
            <div className="three-wrapper">
              <Canvas camera={{ position: [0, 0, 12], fov: 50 }}>
                <ambientLight intensity={0.6} />
                <directionalLight position={[10, 10, 5]} intensity={1} />
                <Suspense fallback={null}>
                  <Spheres count={10} />
                </Suspense>
                <OrbitControls enableZoom={false} enablePan={false} autoRotate autoRotateSpeed={0.4} />
                <Stars radius={50} depth={20} count={200} factor={4} saturation={0} fade />
              </Canvas>
            </div>
          </div>
        </section>

        <section id="projects" className="section card-grid">
          <h3>Projects</h3>
          <div className="projects-grid">
            {projects.map(p => <ProjectCard key={p.name} project={p} />)}
          </div>
        </section>

        <section id="about" className="section card about-card">
          <h3>About</h3>
          <p>I am a DevOps and Cloud Engineer with experience designing resilient AWS infrastructure, container orchestration using Kubernetes, and automating deployments with Terraform and Ansible. I enjoy reducing toil through automation and improving reliability and observability for production systems.</p>

          <div className="split">
            <div>
              <h4>Experience</h4>
              <ul className="muted">
                <li>DevOps / Cloud Engineer — Amazon (Jun 2020 – Jun 2023)</li>
                <li>System Engineer — V‑Cyan IT Services Pvt. (Mar 2018 – May 2020)</li>
              </ul>
            </div>
            <div>
              <h4>Skills</h4>
              <div className="tags">AWS • Azure • Kubernetes • Terraform • Ansible • Jenkins • Docker • Python</div>
            </div>
          </div>
        </section>

        <section id="contact" className="section card contact-card">
          <h3>Contact</h3>
          <p className="muted">Feel free to reach out for collaborations, consulting, or just to say hi.</p>
          <div className="contact-row">
            <div className="contact-card-item"><strong>Email</strong><br/><a href={`mailto:${email}`}>{email}</a></div>
            <div className="contact-card-item"><strong>GitHub</strong><br/><a href={github} target="_blank" rel="noreferrer">{github}</a></div>
            <div className="contact-card-item"><strong>LinkedIn</strong><br/><a href={linkedin} target="_blank" rel="noreferrer">{linkedin}</a></div>
          </div>
        </section>

      </main>

      <footer className="site-footer">
        <div>© {new Date().getFullYear()} Akhil Vadlakonda — Built with React • Three.js</div>
      </footer>
    </div>
  )
}
